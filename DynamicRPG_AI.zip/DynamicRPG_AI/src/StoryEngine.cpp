#include "../include/StoryEngine.h"
#include <iostream>
#include <algorithm>

StoryEngine::StoryEngine() {
    loadStory();
    state = 0;
}

void StoryEngine::loadStory() {
    storyMap[0] = {"You wake up in a cave. Do you go [left] or [right]?"};
    transitions[0] = { {"left", 1}, {"right", 2} };

    storyMap[1] = {"A monster appears. Do you [fight] or [run]?"};
    transitions[1] = { {"fight", 3}, {"run", 4} };

    storyMap[2] = {"You find treasure. Do you [take] or [leave]?"};
    transitions[2] = { {"take", 5}, {"leave", 6} };

    storyMap[3] = {"You slay the monster and win. [end]"};
    transitions[3] = {};

    storyMap[4] = {"You escape but drop your sword. [end]"};
    transitions[4] = {};

    storyMap[5] = {"The treasure is cursed. You turn into stone. [end]"};
    transitions[5] = {};

    storyMap[6] = {"You leave peacefully and return home. [end]"};
    transitions[6] = {};
}

void StoryEngine::start() {
    state = 0;
    memory.clear();
}

std::string StoryEngine::respond(const std::string& input) {
    if (input.empty()) return memoryInfluencedPrompt();

    std::string lowerInput = input;
    std::transform(lowerInput.begin(), lowerInput.end(), lowerInput.begin(), ::tolower);

    if (transitions[state].count(lowerInput)) {
        memory.insert(lowerInput);
        state = transitions[state][lowerInput];
        return memoryInfluencedPrompt();
    }

    return "Invalid choice. Try again.";
}

std::string StoryEngine::memoryInfluencedPrompt() {
    std::string prompt = storyMap[state][0];
    if (!memory.empty()) {
        prompt += "\n[Memory: You have chosen: ";
        for (const auto& item : memory) {
            prompt += item + ", ";
        }
        prompt = prompt.substr(0, prompt.size() - 2) + "]";
    }
    return prompt;
}
