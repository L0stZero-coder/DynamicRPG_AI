#include <iostream>
#include "../include/StoryEngine.h"

int main() {
    StoryEngine engine;
    engine.start();

    std::string input;
    std::cout << "=== Dynamic RPG AI ===" << std::endl;

    while (true) {
        std::cout << engine.respond("") << std::endl;
        std::getline(std::cin, input);

        std::string output = engine.respond(input);
        std::cout << output << std::endl;

        if (output.find("[end]") != std::string::npos) {
            break;
        }
    }

    std::cout << "Game over. Thanks for playing!" << std::endl;
    return 0;
}