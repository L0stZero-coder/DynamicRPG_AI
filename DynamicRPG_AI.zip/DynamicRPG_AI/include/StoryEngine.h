#pragma once
#include <string>
#include <map>
#include <vector>
#include <set>

class StoryEngine {
public:
    StoryEngine();
    void start();
    std::string respond(const std::string& input);

private:
    int state;
    std::set<std::string> memory;
    void loadStory();
    std::map<int, std::vector<std::string>> storyMap;
    std::map<int, std::map<std::string, int>> transitions;
    std::string memoryInfluencedPrompt();
};
