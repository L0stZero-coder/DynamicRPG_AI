This folder will hold visual/audio assets like images, sound effects, and character art for the RPG.
